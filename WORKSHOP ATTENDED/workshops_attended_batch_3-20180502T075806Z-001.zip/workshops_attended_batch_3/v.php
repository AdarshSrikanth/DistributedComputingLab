<html>
<head>
</head>
<body>
<form name="ff" method="get" action="viewimage.php" enctype="multipart/form-data">
<input type="text" name="title" placeholder="Enter title of workshop"/>
<input type="text" name="id" placeholder="Enter id of staff"/>
<input type="text" name="ename" placeholder="Enter ename of staff"/>
<input type="submit" value="submit"/>
</form>

</body>
</html>